﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/location/LocationServiceRequest.h>
#include <aws/location/LocationService_EXPORTS.h>

#include <utility>

namespace Aws {
namespace LocationService {
namespace Model {

/**
 */
class UpdateRouteCalculatorRequest : public LocationServiceRequest {
 public:
  AWS_LOCATIONSERVICE_API UpdateRouteCalculatorRequest() = default;

  // Service request name is the Operation name which will send this request out,
  // each operation should has unique request name, so that we can get operation's name from this request.
  // Note: this is not true for response, multiple operations may have the same response name,
  // so we can not get operation's name from response.
  inline virtual const char* GetServiceRequestName() const override { return "UpdateRouteCalculator"; }

  AWS_LOCATIONSERVICE_API Aws::String SerializePayload() const override;

  ///@{
  /**
   * <p>The name of the route calculator resource to update.</p>
   */
  inline const Aws::String& GetCalculatorName() const { return m_calculatorName; }
  inline bool CalculatorNameHasBeenSet() const { return m_calculatorNameHasBeenSet; }
  template <typename CalculatorNameT = Aws::String>
  void SetCalculatorName(CalculatorNameT&& value) {
    m_calculatorNameHasBeenSet = true;
    m_calculatorName = std::forward<CalculatorNameT>(value);
  }
  template <typename CalculatorNameT = Aws::String>
  UpdateRouteCalculatorRequest& WithCalculatorName(CalculatorNameT&& value) {
    SetCalculatorName(std::forward<CalculatorNameT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>Updates the description for the route calculator resource.</p>
   */
  inline const Aws::String& GetDescription() const { return m_description; }
  inline bool DescriptionHasBeenSet() const { return m_descriptionHasBeenSet; }
  template <typename DescriptionT = Aws::String>
  void SetDescription(DescriptionT&& value) {
    m_descriptionHasBeenSet = true;
    m_description = std::forward<DescriptionT>(value);
  }
  template <typename DescriptionT = Aws::String>
  UpdateRouteCalculatorRequest& WithDescription(DescriptionT&& value) {
    SetDescription(std::forward<DescriptionT>(value));
    return *this;
  }
  ///@}
 private:
  Aws::String m_calculatorName;

  Aws::String m_description;
  bool m_calculatorNameHasBeenSet = false;
  bool m_descriptionHasBeenSet = false;
};

}  // namespace Model
}  // namespace LocationService
}  // namespace Aws
