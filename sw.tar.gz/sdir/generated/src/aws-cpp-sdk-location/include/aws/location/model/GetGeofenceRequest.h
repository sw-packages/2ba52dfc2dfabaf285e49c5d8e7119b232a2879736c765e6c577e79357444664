﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#pragma once
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/location/LocationServiceRequest.h>
#include <aws/location/LocationService_EXPORTS.h>

#include <utility>

namespace Aws {
namespace LocationService {
namespace Model {

/**
 */
class GetGeofenceRequest : public LocationServiceRequest {
 public:
  AWS_LOCATIONSERVICE_API GetGeofenceRequest() = default;

  // Service request name is the Operation name which will send this request out,
  // each operation should has unique request name, so that we can get operation's name from this request.
  // Note: this is not true for response, multiple operations may have the same response name,
  // so we can not get operation's name from response.
  inline virtual const char* GetServiceRequestName() const override { return "GetGeofence"; }

  AWS_LOCATIONSERVICE_API Aws::String SerializePayload() const override;

  ///@{
  /**
   * <p>The geofence collection storing the target geofence.</p>
   */
  inline const Aws::String& GetCollectionName() const { return m_collectionName; }
  inline bool CollectionNameHasBeenSet() const { return m_collectionNameHasBeenSet; }
  template <typename CollectionNameT = Aws::String>
  void SetCollectionName(CollectionNameT&& value) {
    m_collectionNameHasBeenSet = true;
    m_collectionName = std::forward<CollectionNameT>(value);
  }
  template <typename CollectionNameT = Aws::String>
  GetGeofenceRequest& WithCollectionName(CollectionNameT&& value) {
    SetCollectionName(std::forward<CollectionNameT>(value));
    return *this;
  }
  ///@}

  ///@{
  /**
   * <p>The geofence you're retrieving details for.</p>
   */
  inline const Aws::String& GetGeofenceId() const { return m_geofenceId; }
  inline bool GeofenceIdHasBeenSet() const { return m_geofenceIdHasBeenSet; }
  template <typename GeofenceIdT = Aws::String>
  void SetGeofenceId(GeofenceIdT&& value) {
    m_geofenceIdHasBeenSet = true;
    m_geofenceId = std::forward<GeofenceIdT>(value);
  }
  template <typename GeofenceIdT = Aws::String>
  GetGeofenceRequest& WithGeofenceId(GeofenceIdT&& value) {
    SetGeofenceId(std::forward<GeofenceIdT>(value));
    return *this;
  }
  ///@}
 private:
  Aws::String m_collectionName;

  Aws::String m_geofenceId;
  bool m_collectionNameHasBeenSet = false;
  bool m_geofenceIdHasBeenSet = false;
};

}  // namespace Model
}  // namespace LocationService
}  // namespace Aws
