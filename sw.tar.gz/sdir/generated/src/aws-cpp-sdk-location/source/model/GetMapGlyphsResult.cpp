﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/core/AmazonWebServiceResult.h>
#include <aws/core/utils/HashingUtils.h>
#include <aws/core/utils/StringUtils.h>
#include <aws/core/utils/memory/stl/AWSStringStream.h>
#include <aws/location/model/GetMapGlyphsResult.h>

#include <utility>

using namespace Aws::LocationService::Model;
using namespace Aws::Utils::Stream;
using namespace Aws::Utils;
using namespace Aws;

GetMapGlyphsResult::GetMapGlyphsResult(Aws::AmazonWebServiceResult<ResponseStream>&& result) { *this = std::move(result); }

GetMapGlyphsResult& GetMapGlyphsResult::operator=(Aws::AmazonWebServiceResult<ResponseStream>&& result) {
  m_HttpResponseCode = result.GetResponseCode();
  m_blob = result.TakeOwnershipOfPayload();
  m_blobHasBeenSet = true;

  const auto& headers = result.GetHeaderValueCollection();
  const auto& contentTypeIter = headers.find("content-type");
  if (contentTypeIter != headers.end()) {
    m_contentType = contentTypeIter->second;
    m_contentTypeHasBeenSet = true;
  }

  const auto& cacheControlIter = headers.find("cache-control");
  if (cacheControlIter != headers.end()) {
    m_cacheControl = cacheControlIter->second;
    m_cacheControlHasBeenSet = true;
  }

  const auto& requestIdIter = headers.find("x-amzn-requestid");
  if (requestIdIter != headers.end()) {
    m_requestId = requestIdIter->second;
    m_requestIdHasBeenSet = true;
  }

  return *this;
}
