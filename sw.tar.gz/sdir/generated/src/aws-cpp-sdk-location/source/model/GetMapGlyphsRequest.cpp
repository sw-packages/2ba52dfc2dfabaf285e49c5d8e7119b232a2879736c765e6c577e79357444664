﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/core/http/URI.h>
#include <aws/core/utils/json/JsonSerializer.h>
#include <aws/core/utils/memory/stl/AWSStringStream.h>
#include <aws/location/model/GetMapGlyphsRequest.h>

#include <utility>

using namespace Aws::LocationService::Model;
using namespace Aws::Utils::Json;
using namespace Aws::Utils;
using namespace Aws::Http;

Aws::String GetMapGlyphsRequest::SerializePayload() const { return {}; }

void GetMapGlyphsRequest::AddQueryStringParameters(URI& uri) const {
  Aws::StringStream ss;
  if (m_keyHasBeenSet) {
    ss << m_key;
    uri.AddQueryStringParameter("key", ss.str());
    ss.str("");
  }
}
