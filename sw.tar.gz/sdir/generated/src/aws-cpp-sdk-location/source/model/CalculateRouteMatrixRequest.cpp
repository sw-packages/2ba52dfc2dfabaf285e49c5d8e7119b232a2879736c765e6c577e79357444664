﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/core/http/URI.h>
#include <aws/core/utils/json/JsonSerializer.h>
#include <aws/core/utils/memory/stl/AWSStringStream.h>
#include <aws/location/model/CalculateRouteMatrixRequest.h>

#include <utility>

using namespace Aws::LocationService::Model;
using namespace Aws::Utils::Json;
using namespace Aws::Utils;
using namespace Aws::Http;

Aws::String CalculateRouteMatrixRequest::SerializePayload() const {
  JsonValue payload;

  if (m_departurePositionsHasBeenSet) {
    Aws::Utils::Array<JsonValue> departurePositionsJsonList(m_departurePositions.size());
    for (unsigned departurePositionsIndex = 0; departurePositionsIndex < departurePositionsJsonList.GetLength();
         ++departurePositionsIndex) {
      Aws::Utils::Array<JsonValue> positionJsonList(m_departurePositions[departurePositionsIndex].size());
      for (unsigned positionIndex = 0; positionIndex < positionJsonList.GetLength(); ++positionIndex) {
        positionJsonList[positionIndex].AsDouble(m_departurePositions[departurePositionsIndex][positionIndex]);
      }
      departurePositionsJsonList[departurePositionsIndex].AsArray(std::move(positionJsonList));
    }
    payload.WithArray("DeparturePositions", std::move(departurePositionsJsonList));
  }

  if (m_destinationPositionsHasBeenSet) {
    Aws::Utils::Array<JsonValue> destinationPositionsJsonList(m_destinationPositions.size());
    for (unsigned destinationPositionsIndex = 0; destinationPositionsIndex < destinationPositionsJsonList.GetLength();
         ++destinationPositionsIndex) {
      Aws::Utils::Array<JsonValue> positionJsonList(m_destinationPositions[destinationPositionsIndex].size());
      for (unsigned positionIndex = 0; positionIndex < positionJsonList.GetLength(); ++positionIndex) {
        positionJsonList[positionIndex].AsDouble(m_destinationPositions[destinationPositionsIndex][positionIndex]);
      }
      destinationPositionsJsonList[destinationPositionsIndex].AsArray(std::move(positionJsonList));
    }
    payload.WithArray("DestinationPositions", std::move(destinationPositionsJsonList));
  }

  if (m_travelModeHasBeenSet) {
    payload.WithString("TravelMode", TravelModeMapper::GetNameForTravelMode(m_travelMode));
  }

  if (m_departureTimeHasBeenSet) {
    payload.WithString("DepartureTime", m_departureTime.ToGmtString(Aws::Utils::DateFormat::ISO_8601));
  }

  if (m_departNowHasBeenSet) {
    payload.WithBool("DepartNow", m_departNow);
  }

  if (m_distanceUnitHasBeenSet) {
    payload.WithString("DistanceUnit", DistanceUnitMapper::GetNameForDistanceUnit(m_distanceUnit));
  }

  if (m_carModeOptionsHasBeenSet) {
    payload.WithObject("CarModeOptions", m_carModeOptions.Jsonize());
  }

  if (m_truckModeOptionsHasBeenSet) {
    payload.WithObject("TruckModeOptions", m_truckModeOptions.Jsonize());
  }

  return payload.View().WriteReadable();
}

void CalculateRouteMatrixRequest::AddQueryStringParameters(URI& uri) const {
  Aws::StringStream ss;
  if (m_keyHasBeenSet) {
    ss << m_key;
    uri.AddQueryStringParameter("key", ss.str());
    ss.str("");
  }
}
