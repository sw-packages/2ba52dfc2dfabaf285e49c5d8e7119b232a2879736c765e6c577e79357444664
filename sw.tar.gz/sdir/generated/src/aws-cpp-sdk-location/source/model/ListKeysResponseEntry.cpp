﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/core/utils/json/JsonSerializer.h>
#include <aws/location/model/ListKeysResponseEntry.h>

#include <utility>

using namespace Aws::Utils::Json;
using namespace Aws::Utils;

namespace Aws {
namespace LocationService {
namespace Model {

ListKeysResponseEntry::ListKeysResponseEntry(JsonView jsonValue) { *this = jsonValue; }

ListKeysResponseEntry& ListKeysResponseEntry::operator=(JsonView jsonValue) {
  if (jsonValue.ValueExists("KeyName")) {
    m_keyName = jsonValue.GetString("KeyName");
    m_keyNameHasBeenSet = true;
  }
  if (jsonValue.ValueExists("ExpireTime")) {
    m_expireTime = jsonValue.GetString("ExpireTime");
    m_expireTimeHasBeenSet = true;
  }
  if (jsonValue.ValueExists("Description")) {
    m_description = jsonValue.GetString("Description");
    m_descriptionHasBeenSet = true;
  }
  if (jsonValue.ValueExists("Restrictions")) {
    m_restrictions = jsonValue.GetObject("Restrictions");
    m_restrictionsHasBeenSet = true;
  }
  if (jsonValue.ValueExists("CreateTime")) {
    m_createTime = jsonValue.GetString("CreateTime");
    m_createTimeHasBeenSet = true;
  }
  if (jsonValue.ValueExists("UpdateTime")) {
    m_updateTime = jsonValue.GetString("UpdateTime");
    m_updateTimeHasBeenSet = true;
  }
  return *this;
}

JsonValue ListKeysResponseEntry::Jsonize() const {
  JsonValue payload;

  if (m_keyNameHasBeenSet) {
    payload.WithString("KeyName", m_keyName);
  }

  if (m_expireTimeHasBeenSet) {
    payload.WithString("ExpireTime", m_expireTime.ToGmtString(Aws::Utils::DateFormat::ISO_8601));
  }

  if (m_descriptionHasBeenSet) {
    payload.WithString("Description", m_description);
  }

  if (m_restrictionsHasBeenSet) {
    payload.WithObject("Restrictions", m_restrictions.Jsonize());
  }

  if (m_createTimeHasBeenSet) {
    payload.WithString("CreateTime", m_createTime.ToGmtString(Aws::Utils::DateFormat::ISO_8601));
  }

  if (m_updateTimeHasBeenSet) {
    payload.WithString("UpdateTime", m_updateTime.ToGmtString(Aws::Utils::DateFormat::ISO_8601));
  }

  return payload;
}

}  // namespace Model
}  // namespace LocationService
}  // namespace Aws
